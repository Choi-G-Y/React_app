import styled from 'styled-components';

const SimpledButton = styled.button`
color: white;
background-color: chocolate;
`;

const LargeButton = styled(SimpledButton)`
font-size: 50px;
color: white;
background-color: blue;
`;

const ReactButton = props=>{

  return <button className={props.className}>{props.children}</button>;
};

const ReactLargeButton = styled(ReactButton)`
 font-size: 50px;
 `;

const PrimaryButton = styled.button`
  color: ${ props => props.primary ? 'red' : 'blue' };
  background-color: ${ props => props.primary ? 'charcoal' : 'grey' };
`;

const Otherbutton = styled.button`
color : white;
`;

  export default function App() {
    return(
      <div>
        <SimpledButton>SimpledButton</SimpledButton>
        <LargeButton>LargeButton</LargeButton>
        <ReactButton>React</ReactButton>
        <ReactLargeButton>ReactLarge</ReactLargeButton>
        <PrimaryButton primary>Primary</PrimaryButton>
        <PrimaryButton>Normal</PrimaryButton>
        <Otherbutton>other</Otherbutton>

      </div>
    );
  }
